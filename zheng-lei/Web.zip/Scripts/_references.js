﻿/// <reference path="../js/jquery-2.1.1.js" />
/// <reference path="../js/wx.js" />
/// <reference path="http://wx.app.bolaa.net/scenelib/scenelib.js" />